/*
 * Copyright (C) 2015-2015 Intel Corporation.
 * SPDX-License-Identifier: MIT
 */

#error backward compatible header <new.h> is not supported by PinCRT. Use <new> instead
