/*
 * Copyright (C) 2004-2019 Intel Corporation.
 * SPDX-License-Identifier: MIT
 */

#include <stdio.h>

int main()
{
    printf("Hello world\n");
    return 0;
}
